package dev.carphysicsimproved.v1;

public final class BuildInfo {
    public static final String VERSION = "0.4.27-dev";
    public static final String TARGET_GAME = "42";
    public static final String TESTED_GAME = "42.20.4";

    private BuildInfo() {
    }
}
