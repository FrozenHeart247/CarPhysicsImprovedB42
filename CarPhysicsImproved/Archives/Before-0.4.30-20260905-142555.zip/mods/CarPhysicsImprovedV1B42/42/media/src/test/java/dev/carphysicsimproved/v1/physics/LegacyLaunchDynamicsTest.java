package dev.carphysicsimproved.v1.physics;

import pzmod.carphysicsimproved.v1.CarPhysicsImprovedV1Mod;

/** Force/state regression tests, not a native Bullet acceleration-time simulation. */
public final class LegacyLaunchDynamicsTest {
    private LegacyLaunchDynamicsTest() { }

    public static void main(String[] args) {
        var bus = spec(2, 55);
        var automatic = output(bus, false, 1, 9.5, 1, 1.12, false, 1.0 / 60);
        var manual = output(bus, true, 1, 9.5, 1, 1.12, false, 1.0 / 60);
        check(automatic.equals(manual), "Same-state auto/manual use identical drivetrain output");
        check(automatic.rawDriveForce() > automatic.engineForce() * 2,
                "B700-like launch is strongly traction-limited");
        double launch = LegacyLaunchDynamics.forceScale(bus, 1, 9.5, .7);
        near(launch, .7, "Full low-speed reduction");
        var softened = LegacyLaunchDynamics.withDelivery(automatic, launch);
        near(softened.engineForce(), automatic.engineForce() * .7,
                "Reduction must work even when raw torque exceeds the traction cap");
        check(softened.equals(LegacyLaunchDynamics.withDelivery(manual, launch)),
                "Same reduction in auto/manual");

        int checked = 0;
        for (int type = 1; type <= 3; type++) {
            for (double top : new double[]{10, 55, 65, 85, 120}) {
                var spec = spec(type, top);
                double previousScale = .7;
                for (int speed = 0; speed <= 150; speed++) {
                    double scale = LegacyLaunchDynamics.forceScale(spec, 1, speed, .7);
                    check(scale >= previousScale && scale <= 1, "Smooth fade never strengthens the reduction");
                    if (speed > 0) check(scale - previousScale < .023, "No abrupt per-speed-unit force step");
                    previousScale = scale;
                }
                for (boolean manualMode : new boolean[]{false, true}) {
                    for (int gear = -1; gear <= 8; gear++) {
                        for (double speed : new double[]{-45, -10, 0, 10, 25, 45, 80}) {
                            for (double throttle : new double[]{0, .5, 1}) {
                                for (double grip : new double[]{.1, .7, 1.12}) {
                                    for (double dt : new double[]{1.0 / 30, 1.0 / 60, 1.0 / 120}) {
                                        var source = output(spec, manualMode, gear, speed, throttle, grip,
                                                grip < .7, dt);
                                        double scale = LegacyLaunchDynamics.forceScale(spec, source.gear(), speed, .7);
                                        var tuned = LegacyLaunchDynamics.withDelivery(source, scale);
                                        var otherFields = new LegacyPhysics.Output(source.gear(), tuned.engineForce(),
                                                source.brakingForce(), source.steeringRadians(), source.dragMagnitude(),
                                                source.tireTraction(), source.burnoutSpeedKph(), source.engineRpm(),
                                                source.throttle(), source.rawDriveForce(), source.clutchKickIntensity());
                                        check(tuned.equals(otherFields), "Only delivered drive force may change");
                                        check(Math.abs(tuned.engineForce()) <= Math.abs(source.engineForce()),
                                                "Must not exceed the existing drive/grip limit");
                                        if (type != 2 || source.gear() <= 0 || source.engineForce() <= 0 || Math.abs(speed) >= 70) {
                                            check(tuned == source, "Unaffected class/reverse/coast/high-speed is exact passthrough");
                                        }
                                        check(LegacyLaunchDynamics.withDelivery(source,
                                                LegacyLaunchDynamics.forceScale(spec, source.gear(), speed, 1)) == source,
                                                "100 percent restores the exact original output");
                                        checked++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        near(LegacyLaunchDynamics.forceScale(bus, 1, 50, .7), 1,
                "Fast sideways movement is judged by total native speed, not forward projection");
        near(LegacyLaunchDynamics.forceScale(bus, 1, Double.NaN, .7), 1, "Invalid speed fails open");
        near(LegacyLaunchDynamics.sanitize(Double.NaN), .7, "Invalid option uses default");
        near(LegacyLaunchDynamics.sanitize(-1), .25, "No zero/reversed drive from invalid option");
        near(LegacyLaunchDynamics.sanitize(2), 1, "No boost beyond the existing grip cap");
        CarPhysicsImprovedV1Mod.configureHeavyLaunch(.85);
        CarPhysicsImprovedV1Mod.configurePhysics(1, 1, 1, 2.5, 40, .7, 1, 1.5,
                .05, .1, .2, 1, 1, 1, .6, .7, .4);
        CarPhysicsImprovedV1Mod.configureSteering(1, .1, 1, .1, 3, 75);
        near(CarPhysicsImprovedV1Mod.heavyLaunchMultiplier(), .85,
                "Reapplying physics/steering must not discard independent launch setting");
        CarPhysicsImprovedV1Mod.configureHeavyLaunch(1);
        near(CarPhysicsImprovedV1Mod.heavyLaunchMultiplier(), 1, "Lua bridge can disable the feature");
        CarPhysicsImprovedV1Mod.configureHeavyLaunch(.7);
        System.out.println("LegacyLaunchDynamicsTest: " + checked
                + " same-state comparisons; saturated launch, fade, auto/manual, passthrough and config passed");
    }

    private static LegacyPhysics.Spec spec(int type, double top) {
        return new LegacyPhysics.Spec("Base.LaunchTest" + type, 1315, 505, top,
                750, 4500, 4350, 3, LegacyPhysics.legacyRatios(8), 50, .8, 1, type);
    }

    private static LegacyPhysics.Output output(LegacyPhysics.Spec spec, boolean manual, int gear,
            double speed, double throttle, double grip, boolean offroad, double dt) {
        var state = new LegacyPhysics.State();
        state.gear = gear;
        state.lastStepGear = gear;
        state.engineRpm = 2849;
        state.throttle = throttle;
        state.fullThrottleSeconds = 1;
        return LegacyPhysics.step(spec, new LegacyPhysics.Conditions(1, grip, 1, offroad),
                LegacyPhysics.Settings.defaults(), new LegacyPhysics.Input(speed / 3.6, true,
                        throttle > 0 && (manual || gear >= 0), throttle > 0 && !manual && gear < 0,
                        false, false, .4, throttle, manual, gear), state, dt);
    }

    private static void near(double actual, double expected, String message) {
        check(Math.abs(actual - expected) < 1e-9, message + ": " + actual + " != " + expected);
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
