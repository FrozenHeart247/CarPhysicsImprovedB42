package dev.carphysicsimproved.v1.runtime;

import dev.carphysicsimproved.v1.physics.LegacyKeyDrift;
import java.lang.reflect.Field;

/** Exercises production adapter bookkeeping with fake native fields/methods, not a Bullet world. */
public final class LegacyKeyDriftAdapterTest {
    private LegacyKeyDriftAdapterTest() { }

    public static void main(String[] args) throws Exception {
        withoutWorldAccess(); // Resolve real ABI, forbid world-census dependencies.
        PzLegacyAccess access = LegacyMultiplayerRuntimeTest.fixtureAccess();
        pzmod.carphysicsimproved.v1.CarPhysicsImprovedV1Mod.setEnabled(true);
        replace(access, "vehicleScript", Car.class.getMethod("getScript"));
        replace(access, "vehicleMass", Car.class.getMethod("getMass"));
        replace(access, "vehicleNativeMass", Car.class.getMethod("getMass"));

        Car a = new Car(new LegacyMultiplayerRuntimeTest.Script(), 1200);
        a.script.wheelFriction = 3;
        access.applyKeyDriftFriction(a, 1.125, .35);
        near(a.nativeFriction, .63, "Reference 1.8 cap is before drift multiplier");
        for (int i = 0; i < 120; i++) access.applyKeyDriftFriction(a, 1.125, .35);
        near(a.nativeFriction, .63, "No repeated multiplication");
        check(a.submissions == 1, "Unchanged friction is not resubmitted every tick");
        access.applyKeyDriftFriction(a, .1, .35);
        near(a.nativeFriction, .105, "New drift grip may be below legacy .12 scale floor");
        access.applyWheelFrictionScale(a, .7);
        near(a.nativeFriction, 2.1, "Release preserves current environmental penalty");
        access.applyWheelFrictionScale(a, 1);
        near(a.nativeFriction, 3, "Release on dry road restores original friction");
        a.script.wheelFriction = 1.4f;
        access.applyKeyDriftFriction(a, 1, .35);
        near(a.nativeFriction, .49, "New entry reads current baseline");
        access.restoreAllWheelFriction();
        near(a.nativeFriction, 1.4, "Disable/failure cleanup restores baseline");
        Car sameType = new Car(a.script, 1200);
        access.applyWheelFrictionScale(a, .2);
        access.applyWheelFrictionScale(sameType, .5);
        near(a.nativeFriction, .28, "First car retains its independent multiplier");
        near(sameType.nativeFriction, .7, "Second car has its own multiplier");
        near(a.script.wheelFriction, 1.4, "Shared script is never changed");
        access.restoreWheelFriction(a);
        near(a.nativeFriction, 1.4, "First car restored");
        near(sameType.nativeFriction, .7, "First car cannot restore another car");
        access.restoreWheelFriction(sameType);
        near(sameType.nativeFriction, 1.4, "Second car restored");

        access.applyWheelFrictionScale(a, .2);
        Field states = PzLegacyAccess.class.getDeclaredField("vehicleFrictionStates");
        states.setAccessible(true);
        Object state = ((java.util.Map<?, ?>) states.get(access)).get(a);
        Field updatedAt = state.getClass().getDeclaredField("updatedAt");
        updatedAt.setAccessible(true);
        updatedAt.setLong(state, System.nanoTime() - 1_000_000_000L);
        access.restoreAbandonedWheelFriction();
        near(a.nativeFriction, 1.4, "Expired request restores without controller callback");
        a.failNextSubmission = true;
        boolean failed = false;
        try { access.applyWheelFrictionScale(a, .2); }
        catch (IllegalStateException expected) { failed = true; }
        check(failed, "Fixture must exercise failed native submission");
        access.restoreAllWheelFriction();
        near(a.nativeFriction, 1.4, "Failed entry still restores the tracked baseline");
        near(a.nativeFriction, 1.4, "Failed entry restores native definition too");
        access.applyWheelFrictionScale(a, .2);
        a.failNextSubmission = true;
        failed = false;
        try { access.restoreWheelFriction(a); }
        catch (IllegalStateException expected) { failed = true; }
        check(failed, "Fixture must exercise failed native restoration");
        near(a.script.wheelFriction, 1.4, "Java shared baseline untouched by failed native publish");
        access.restoreAllWheelFriction();
        near(a.nativeFriction, 1.4, "Retry republishes even when Java already has baseline");
        Car b = new Car(new LegacyMultiplayerRuntimeTest.Script(), 2000);
        var tuning = LegacyKeyDrift.Tuning.defaults();
        double originalTorque = access.keyDriftTorque(a, true, 1, 1, tuning);
        near(originalTorque, 4704, "Fixed gain applied to current car only");
        for (int i = 0; i < 20; i++) {
            near(access.keyDriftTorque(a, true, 1, 1, tuning), originalTorque, "No accumulated gain");
        }
        check(b.reads == 0, "Other vehicle masses are never requested");
        b.mass = 6000;
        near(access.keyDriftTorque(a, true, 1, 1, tuning), originalTorque, "Other car weight cannot change yaw");
        near(access.keyDriftTorque(b, true, 1, 1, tuning), 23520, "Each car uses its own body mass");
        near(access.keyDriftTorque(a, true, 1, 1, tuning), originalTorque, "Switching cars cannot leak gain");
        PzLegacyAccess freshAccess = withoutWorldAccess();
        replace(freshAccess, "vehicleNativeMass", Car.class.getMethod("getMass"));
        near(freshAccess.keyDriftTorque(a, true, 1, 1, tuning), originalTorque, "Fresh session has identical yaw");
        near(access.keyDriftTorque(a, true, -1, 1, tuning), -originalTorque, "Immediate countersteer");
        near(access.keyDriftTorque(null, false, 1, 1, tuning), 0, "Inactive drift does not even read a body");
        check(a.mass == 1200 && b.mass == 6000, "Adapter must never rewrite vehicle masses");
        a.mass = 1500;
        near(access.keyDriftTorque(a, true, 1, 1, tuning), 5880, "Actual own-body mass change is still respected");
        System.out.println("LegacyKeyDriftAdapterTest: actual friction adapter, fresh restoration, "
                + "capped/multiplied grip and world-independent own-body yaw passed");
    }

    private static PzLegacyAccess withoutWorldAccess() throws Exception {
        Thread thread = Thread.currentThread();
        ClassLoader original = thread.getContextClassLoader();
        ClassLoader noWorld = new ClassLoader(original) {
            @Override
            protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
                if (name.equals("zombie.iso.IsoWorld") || name.equals("zombie.iso.IsoCell")) {
                    throw new AssertionError("Drift adapter must not resolve world/cell access: " + name);
                }
                return super.loadClass(name, resolve);
            }
        };
        thread.setContextClassLoader(noWorld);
        try { return new PzLegacyAccess(); }
        finally { thread.setContextClassLoader(original); }
    }

    private static void replace(PzLegacyAccess access, String name, Object value) throws Exception {
        Field field = PzLegacyAccess.class.getDeclaredField(name);
        field.setAccessible(true);
        field.set(access, value);
    }

    public static final class Car extends LegacyMultiplayerRuntimeTest.Car {
        private double mass;
        private int reads;
        Car(LegacyMultiplayerRuntimeTest.Script script, double mass) { this.script = script; this.mass = mass; }
        @Override public LegacyMultiplayerRuntimeTest.Script getScript() { return script; }
        public double getMass() { reads++; return mass; }
    }
    private static void near(double actual, double expected, String message) {
        check(Double.isFinite(actual) && Math.abs(actual - expected) < 1e-6, message + ": " + actual + " / " + expected);
    }
    private static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
}
